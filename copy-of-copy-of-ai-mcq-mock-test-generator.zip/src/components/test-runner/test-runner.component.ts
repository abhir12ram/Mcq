import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, computed, effect, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TestStateService } from '../../services/test-state.service';
import { Question, UserAnswer } from '../../models/question.model';

// FIX: Define a type alias for answer state to ensure type safety and improve readability.
type AnswerState = { selectedOptionIndex: number | null, isMarkedForReview: boolean };

@Component({
  selector: 'app-test-runner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-runner.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestRunnerComponent implements OnInit, OnDestroy {
  testStateService = inject(TestStateService);
  router = inject(Router);

  test = this.testStateService.activeTest;
  questions = computed(() => this.test()?.questions || []);
  
  currentIndex = signal(0);
  currentQuestion = computed<Question | undefined>(() => this.questions()[this.currentIndex()]);

  userAnswers = signal<Map<string, AnswerState>>(new Map());

  timer = signal(0);
  timerInterval: any;

  constructor() {
    effect(() => {
        if (!this.test()) {
            this.router.navigate(['/create-test']);
        }
    });
  }

  ngOnInit() {
    if (this.test()) {
      this.initializeAnswers();
      this.startTimer();
    }
  }

  ngOnDestroy() {
    clearInterval(this.timerInterval);
  }
  
  initializeAnswers() {
    // FIX: Explicitly define the type for the Map to ensure type safety.
    const initialAnswers = new Map<string, AnswerState>();
    this.questions().forEach(q => {
      initialAnswers.set(q.id, { selectedOptionIndex: null, isMarkedForReview: false });
    });
    this.userAnswers.set(initialAnswers);
  }

  startTimer() {
    const duration = (this.test()?.questionCount || 0) * 60; // 1 minute per question
    this.timer.set(duration);
    this.timerInterval = setInterval(() => {
      this.timer.update(t => {
        if (t <= 1) {
          clearInterval(this.timerInterval);
          this.submitTest();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  }
  
  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  selectOption(optionIndex: number) {
    const qId = this.currentQuestion()?.id;
    if (qId) {
      this.userAnswers.update(answers => {
        // FIX: Explicitly type the new Map to prevent type inference issues where `current` becomes `unknown`.
        const newAnswers = new Map<string, AnswerState>(answers);
        const current = newAnswers.get(qId);
        if (current) {
          newAnswers.set(qId, { ...current, selectedOptionIndex: optionIndex });
        }
        return newAnswers;
      });
    }
  }
  
  toggleMarkForReview() {
      const qId = this.currentQuestion()?.id;
      if (qId) {
        this.userAnswers.update(answers => {
            // FIX: Explicitly type the new Map to prevent type inference issues where `current` becomes `unknown`.
            const newAnswers = new Map<string, AnswerState>(answers);
            const current = newAnswers.get(qId);
            if(current) {
                newAnswers.set(qId, {...current, isMarkedForReview: !current.isMarkedForReview });
            }
            return newAnswers;
        });
      }
  }
  
  isCurrentMarkedForReview() {
      const qId = this.currentQuestion()?.id;
      return qId ? this.userAnswers().get(qId)?.isMarkedForReview : false;
  }

  goToQuestion(index: number) {
    if (index >= 0 && index < this.questions().length) {
      this.currentIndex.set(index);
    }
  }
  
  nextQuestion() {
      this.goToQuestion(this.currentIndex() + 1);
  }
  
  prevQuestion() {
      this.goToQuestion(this.currentIndex() - 1);
  }

  submitTest() {
    if (!confirm('Are you sure you want to submit the test?')) return;
    
    clearInterval(this.timerInterval);
    
    const finalAnswers: UserAnswer[] = [];
    let correctCount = 0;
    
    this.questions().forEach(q => {
        const userAnswer = this.userAnswers().get(q.id);
        const isCorrect = userAnswer?.selectedOptionIndex === q.correctAnswerIndex;
        if (isCorrect) correctCount++;
        
        finalAnswers.push({
            questionId: q.id,
            selectedOptionIndex: userAnswer?.selectedOptionIndex ?? null,
            isCorrect: userAnswer?.selectedOptionIndex !== null ? isCorrect : false,
            isMarkedForReview: userAnswer?.isMarkedForReview ?? false
        });
    });

    const total = this.questions().length;
    const skipped = finalAnswers.filter(a => a.selectedOptionIndex === null).length;
    const incorrect = total - correctCount - skipped;

    this.testStateService.setTestResult({
        totalQuestions: total,
        correctAnswers: correctCount,
        incorrectAnswers: incorrect,
        skippedAnswers: skipped,
        score: total > 0 ? (correctCount / total) * 100 : 0,
        userAnswers: finalAnswers,
        questions: this.questions()
    });
    
    this.testStateService.clearTestState();
    this.router.navigate(['/results']);
  }
}