import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { QuestionService } from '../../services/question.service';
import { GeminiService } from '../../services/gemini.service';
import { Question } from '../../models/question.model';
import { SpinnerComponent } from '../spinner/spinner.component';
import { ModalComponent } from '../modal/modal.component';

@Component({
  selector: 'app-question-bank',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SpinnerComponent, ModalComponent],
  templateUrl: './question-bank.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QuestionBankComponent {
  questionService = inject(QuestionService);
  geminiService = inject(GeminiService);
  private fb = inject(FormBuilder);

  questions = this.questionService.questions;
  isModalOpen = signal(false);
  editingQuestion = signal<Question | null>(null);
  questionForm!: FormGroup;

  selectedFiles = signal<{ file: File; preview: string }[]>([]);
  isGenerating = this.geminiService.loading;
  generationError = this.geminiService.error;
  
  generationMessages = [
    "Analyzing your notes...",
    "Identifying key concepts...",
    "Crafting challenging questions...",
    "Polishing explanations...",
    "Almost there..."
  ];
  currentMessage = signal(this.generationMessages[0]);

  categories = this.questionService.categories;
  selectedCategory = signal<string>('all');

  defaultCategories = ['Political Science', 'Geography', 'Economics', 'History', 'General Knowledge'];
  
  allAvailableCategories = computed(() => {
    const existing = this.categories();
    const combined = [...new Set([...this.defaultCategories, ...existing])];
    return combined.sort();
  });

  filteredQuestions = computed(() => {
    const category = this.selectedCategory();
    const allQuestions = this.questions();
    if (category === 'all') {
      return allQuestions;
    }
    return allQuestions.filter(q => q.category === category);
  });

  constructor() {
    this.initForm();
  }

  initForm(question: Question | null = null) {
    this.questionForm = this.fb.group({
      id: [question?.id || null],
      question: [question?.question || '', Validators.required],
      options: this.fb.array(
        question?.options.map(opt => this.fb.control(opt, Validators.required)) ||
        [...Array(4)].map(() => this.fb.control('', Validators.required)),
        Validators.required
      ),
      correctAnswerIndex: [question?.correctAnswerIndex ?? null, [Validators.required, Validators.min(0), Validators.max(3)]],
      explanation: [question?.explanation || '', Validators.required],
      category: [question?.category || '', Validators.required],
    });
  }

  get options(): FormArray {
    return this.questionForm.get('options') as FormArray;
  }
  
  openAddModal() {
    this.editingQuestion.set(null);
    this.initForm();
    this.isModalOpen.set(true);
  }

  openEditModal(question: Question) {
    this.editingQuestion.set(question);
    this.initForm(question);
    this.isModalOpen.set(true);
  }

  closeModal() {
    this.isModalOpen.set(false);
    this.editingQuestion.set(null);
  }

  saveQuestion() {
    if (this.questionForm.invalid) {
      return;
    }
    const formValue = this.questionForm.value;
    if (this.editingQuestion()) {
      this.questionService.updateQuestion(formValue);
    } else {
      const { id, ...newQuestion } = formValue;
      this.questionService.addQuestion(newQuestion);
    }
    this.closeModal();
  }
  
  deleteQuestion(id: string) {
    if (confirm('Are you sure you want to delete this question?')) {
        this.questionService.deleteQuestion(id);
    }
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      const files = Array.from(input.files);
      const filePreviews = files.map(file => ({
        file,
        preview: URL.createObjectURL(file),
      }));
      this.selectedFiles.set(filePreviews);
    }
  }

  removeFile(index: number): void {
    this.selectedFiles.update(files => {
      const newFiles = [...files];
      URL.revokeObjectURL(newFiles[index].preview);
      newFiles.splice(index, 1);
      return newFiles;
    });
  }

  async generateQuestions() {
    if (this.selectedFiles().length === 0) return;
    
    const messageInterval = setInterval(() => {
        this.currentMessage.update(msg => {
            const currentIndex = this.generationMessages.indexOf(msg);
            const nextIndex = (currentIndex + 1) % this.generationMessages.length;
            return this.generationMessages[nextIndex];
        });
    }, 3000);

    const imagePromises = this.selectedFiles().map(fileItem => this.fileToBase64(fileItem.file));
    const base64Images = await Promise.all(imagePromises);
    
    const generatedQuestions = await this.geminiService.generateMcqsFromImages(base64Images);
    clearInterval(messageInterval);
    
    if (generatedQuestions && generatedQuestions.length > 0) {
      this.questionService.addMultipleQuestions(generatedQuestions);
      this.selectedFiles.set([]);
    }
  }

  private fileToBase64(file: File): Promise<{ mimeType: string; data: string }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64Data = result.split(',')[1];
        resolve({ mimeType: file.type, data: base64Data });
      };
      reader.onerror = error => reject(error);
    });
  }

  exportToJson() {
    const dataStr = JSON.stringify(this.questions(), null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = 'questions.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }

  filterByCategory(category: string): void {
    this.selectedCategory.set(category);
  }
}