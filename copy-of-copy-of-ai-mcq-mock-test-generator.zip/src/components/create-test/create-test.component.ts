import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { QuestionService } from '../../services/question.service';
import { TestStateService } from '../../services/test-state.service';
import { Question } from '../../models/question.model';

@Component({
  selector: 'app-create-test',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './create-test.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateTestComponent {
  questionService = inject(QuestionService);
  testStateService = inject(TestStateService);

  questionCountOptions = [10, 20, 50];
  private allQuestions = this.questionService.questions;
  
  categories = computed(() => ['All Questions', ...this.questionService.categories()]);
  selectedCategory = signal<string>('All Questions');

  availableQuestions = computed(() => {
    const category = this.selectedCategory();
    const questions = this.allQuestions();
    if (category === 'All Questions') {
      return questions;
    }
    return questions.filter(q => q.category === category);
  });
  
  selectedQuestionCount = signal<number>(10);
  
  canStartTest = computed(() => this.availableQuestions().length >= this.selectedQuestionCount());

  selectCategory(event: Event) {
    const selectElement = event.target as HTMLSelectElement;
    this.selectedCategory.set(selectElement.value);
  }

  startTest() {
    if (!this.canStartTest()) return;
    
    const shuffled = this.shuffleArray([...this.availableQuestions()]);
    const selectedQuestions = shuffled.slice(0, this.selectedQuestionCount());
    
    this.testStateService.startTest({
      questionCount: this.selectedQuestionCount(),
      questions: selectedQuestions
    });
  }

  private shuffleArray(array: Question[]): Question[] {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
}