import { ChangeDetectionStrategy, Component, OnInit, computed, effect, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TestStateService } from '../../services/test-state.service';
import { GeminiService } from '../../services/gemini.service';
import { TestResult, UserAnswer } from '../../models/question.model';
import { SpinnerComponent } from '../spinner/spinner.component';

@Component({
  selector: 'app-test-results',
  standalone: true,
  imports: [CommonModule, RouterLink, SpinnerComponent],
  templateUrl: './test-results.component.html',
  styleUrls: ['./test-results.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestResultsComponent implements OnInit {
  testStateService = inject(TestStateService);
  geminiService = inject(GeminiService);
  router = inject(Router);

  result = this.testStateService.testResult;
  aiFeedback = signal<string>('');
  isGeneratingFeedback = this.geminiService.loading;
  
  scoreProperties = computed(() => {
      const score = this.result()?.score ?? 0;
      const circumference = 2 * Math.PI * 45; // 2 * pi * radius
      const offset = circumference - (score / 100) * circumference;
      return {
          strokeDasharray: circumference,
          strokeDashoffset: offset
      };
  });
  
  constructor() {
    effect(() => {
        if (!this.result()) {
            this.router.navigate(['/create-test']);
        }
    });
  }

  ngOnInit() {
    if (this.result()) {
      this.generateFeedback(this.result()!);
    }
  }

  async generateFeedback(result: TestResult) {
      const feedback = await this.geminiService.generateFeedback(result);
      this.aiFeedback.set(feedback);
  }
  
  getAnswerClass(questionId: string, optionIndex: number): string {
    const userAnswer = this.result()?.userAnswers.find(ua => ua.questionId === questionId);
    const question = this.result()?.questions.find(q => q.id === questionId);
    if (!userAnswer || !question) return '';
    
    const isSelected = userAnswer.selectedOptionIndex === optionIndex;
    const isCorrect = question.correctAnswerIndex === optionIndex;

    if (isCorrect) {
        return 'bg-green-500/20 border-green-500';
    }
    if (isSelected && !isCorrect) {
        return 'bg-red-500/20 border-red-500';
    }
    return 'bg-base-100 dark:bg-dark-base-100 border-base-200 dark:border-dark-base-300';
  }
}
