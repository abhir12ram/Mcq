import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, GenerateContentResponse, Type } from '@google/genai';
import { Question, TestResult } from '../models/question.model';

// This is a placeholder for the environment variable.
// In a real app, this would be handled by a build process.
declare const process: any;

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;
  public error = signal<string | null>(null);
  public loading = signal<boolean>(false);

  constructor() {
    try {
      // In a real Applet environment, process.env.API_KEY would be available.
      // For local development, you might need to mock this or use a local proxy.
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error('API_KEY environment variable not found.');
      }
      this.ai = new GoogleGenAI({ apiKey });
    } catch (e: any) {
      console.error('Failed to initialize Gemini AI Service:', e.message);
      this.error.set('Failed to initialize AI Service. API Key might be missing.');
    }
  }

  async generateMcqsFromImages(images: { mimeType: string; data: string }[]): Promise<Question[]> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return [];
    }

    this.loading.set(true);
    this.error.set(null);

    const imageParts = images.map(image => ({
      inlineData: {
        mimeType: image.mimeType,
        data: image.data,
      },
    }));

    const textPart = {
      text: `Analyze the text in these images. Based on the content, generate a list of multiple-choice questions (MCQs). Each MCQ should test a key concept from the text. For each question, provide: a question, four distinct options, the index of the correct answer (0-3), a brief but clear explanation for why the answer is correct, and a relevant category for the question (e.g., "Political Science", "Geography", "Economics"). Structure your response as a JSON array.`
    };

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [...imageParts, textPart] },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswerIndex: { type: Type.INTEGER },
                explanation: { type: Type.STRING },
                category: { type: Type.STRING },
              },
              required: ['question', 'options', 'correctAnswerIndex', 'explanation', 'category']
            }
          }
        }
      });
      
      const jsonText = response.text.trim();
      const generatedQuestions = JSON.parse(jsonText) as Omit<Question, 'id'>[];

      return generatedQuestions.map(q => ({ ...q, id: crypto.randomUUID() }));

    } catch (e: any) {
      console.error('Error generating MCQs:', e);
      this.error.set(`Failed to generate questions. ${e.message}`);
      return [];
    } finally {
      this.loading.set(false);
    }
  }

  async generateFeedback(result: TestResult): Promise<string> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return "AI Service not available.";
    }

    this.loading.set(true);
    this.error.set(null);

    const incorrectQuestions = result.userAnswers
      .filter(ua => !ua.isCorrect)
      .map(ua => result.questions.find(q => q.id === ua.questionId))
      .filter((q): q is Question => !!q);
      
    if (incorrectQuestions.length === 0) {
        this.loading.set(false);
        return "Excellent work! You answered all questions correctly. Keep up the great momentum and continue practicing to solidify your knowledge."
    }

    const prompt = `
      A student has completed a mock test with the following results:
      - Total Questions: ${result.totalQuestions}
      - Correct Answers: ${result.correctAnswers}
      - Incorrect Answers: ${result.incorrectAnswers}
      
      Here are the questions they answered incorrectly:
      ${incorrectQuestions.map(q => `
        - Question: ${q.question}
        - Their Answer: ${q.options[result.userAnswers.find(ua => ua.questionId === q.id)?.selectedOptionIndex ?? -1] || 'Skipped'}
        - Correct Answer: ${q.options[q.correctAnswerIndex]}
        - Explanation: ${q.explanation}
      `).join('')}

      Based on these incorrect answers, provide concise, encouraging, and actionable feedback. Identify potential patterns of misunderstanding or weak areas. Suggest specific topics to review and offer study strategies to help them improve. Keep the feedback positive and focused on growth. Address the student directly.
    `;

    try {
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text;
    } catch (e: any) {
        console.error('Error generating feedback:', e);
        this.error.set(`Failed to generate feedback. ${e.message}`);
        return "Could not generate AI feedback at this time.";
    } finally {
        this.loading.set(false);
    }
  }
}