import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  isDarkMode = signal<boolean>(false);

  initializeTheme() {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const storedTheme = localStorage.getItem('theme');
    if (storedTheme) {
      this.isDarkMode.set(storedTheme === 'dark');
    } else {
      this.isDarkMode.set(prefersDark);
    }
  }

  toggleTheme() {
    this.isDarkMode.update(isDark => {
      const newTheme = !isDark ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      return !isDark;
    });
  }
}
