import { Injectable, signal, computed, effect } from '@angular/core';
import { Question } from '../models/question.model';

@Injectable({
  providedIn: 'root',
})
export class QuestionService {
  private readonly STORAGE_KEY = 'mcq_questions';
  private _questions = signal<Question[]>([]);

  public questions = this._questions.asReadonly();
  public categories = computed(() => {
    const allQuestions = this.questions();
    const uniqueCategories = [...new Set(allQuestions.map(q => q.category))];
    return uniqueCategories.sort();
  });

  constructor() {
    this.loadQuestionsFromStorage();
    effect(() => {
      this.saveQuestionsToStorage(this._questions());
    });
  }

  private loadQuestionsFromStorage() {
    try {
      const storedQuestions = localStorage.getItem(this.STORAGE_KEY);
      if (storedQuestions) {
        const questions = JSON.parse(storedQuestions);
        // Data migration for questions without a category
        const migratedQuestions = questions.map((q: any) => ({
          ...q,
          category: q.category || 'Uncategorized'
        }));
        this._questions.set(migratedQuestions);
      }
    } catch (e) {
      console.error('Error loading questions from localStorage', e);
      this._questions.set([]);
    }
  }

  private saveQuestionsToStorage(questions: Question[]) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(questions));
    } catch (e) {
      console.error('Error saving questions to localStorage', e);
    }
  }

  addQuestion(question: Omit<Question, 'id'>) {
    const newQuestion: Question = {
      ...question,
      id: crypto.randomUUID(),
    };
    this._questions.update(questions => [...questions, newQuestion]);
  }
  
  addMultipleQuestions(newQuestions: Question[]) {
      this._questions.update(currentQuestions => [...currentQuestions, ...newQuestions]);
  }

  updateQuestion(updatedQuestion: Question) {
    this._questions.update(questions =>
      questions.map(q => (q.id === updatedQuestion.id ? updatedQuestion : q))
    );
  }

  deleteQuestion(id: string) {
    this._questions.update(questions => questions.filter(q => q.id !== id));
  }

  deleteAllQuestions() {
    this._questions.set([]);
  }

  getQuestionById(id: string): Question | undefined {
    return this.questions().find(q => q.id === id);
  }
}