import { Injectable, signal } from '@angular/core';
import { TestConfig, TestResult } from '../models/question.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class TestStateService {
  private _activeTest = signal<TestConfig | null>(null);
  private _testResult = signal<TestResult | null>(null);

  public activeTest = this._activeTest.asReadonly();
  public testResult = this._testResult.asReadonly();

  constructor(private router: Router) {}

  startTest(config: TestConfig) {
    if (!config || config.questions.length === 0) {
      console.error("Cannot start test with no questions.");
      return;
    }
    const shuffledQuestions = this.shuffleArray([...config.questions]);
    const questionsWithShuffledOptions = shuffledQuestions.map(q => ({
      ...q,
      options: this.shuffleArray([...q.options])
    }));
    
    this._activeTest.set({ ...config, questions: questionsWithShuffledOptions });
    this.router.navigate(['/test-runner']);
  }

  setTestResult(result: TestResult) {
    this._testResult.set(result);
  }
  
  clearTestState() {
      this._activeTest.set(null);
  }

  private shuffleArray<T>(array: T[]): T[] {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
}
