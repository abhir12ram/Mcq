export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  category: string;
}

export interface TestConfig {
  questionCount: number;
  questions: Question[];
}

export interface UserAnswer {
  questionId: string;
  selectedOptionIndex: number | null; // null if skipped
  isCorrect: boolean;
  isMarkedForReview: boolean;
}

export interface TestResult {
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  skippedAnswers: number;
  score: number;
  userAnswers: UserAnswer[];
  questions: Question[];
  aiFeedback?: string;
}